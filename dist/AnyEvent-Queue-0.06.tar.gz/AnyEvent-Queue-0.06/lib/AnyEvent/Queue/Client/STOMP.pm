package AnyEvent::Queue::Client::STOMP;

use strict;
use Carp;
use base 'AnyEvent::Queue::Client';

# TODO

1;
