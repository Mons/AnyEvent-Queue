#!/usr/bin/perl

use lib::abs '../..';
use strict;
use AnyEvent::Impl::Perl;
use AnyEvent;
use AnyEvent::Queue::Client::Beanstalk;
use R::Dump;
use Data::Dumper;
use Devel::Size 'total_size';
#use Devel::Leak::Object 'GLOBAL_bless';
#use Devel::LeakTrace;

$0 = 'atom stream test client using anyevent';

my $cv = AnyEvent->condvar;
$SIG{INT} = sub { $cv->send };
my $idle; $idle = AnyEvent->idle(cb => sub {
	#warn "Fuck, I do nothing";
	#$cv->send;
});

sub mem () {
	my $ps = (split /\n/,`ps auxwp $$`)[1];
	my ($mem) = $ps =~ /\w+\s+\d+\s+\S+\s+\S+\s+(\d+)\s+(\d+)/;
	return $mem;
}

our $cmem = 0;
sub measure ($) {
	my $op = shift;
	my $mem = mem;
	my $delta = $mem - $cmem;
	if ($delta != 0) {
		$cmem = $mem;
		warn sprintf "%s: %+d\n",$op,$delta;
	}
}
measure('start');
my $cl = AnyEvent::Queue::Client::Beanstalk->new(
	servers => ['localhost:11322'],
	timeout => 1,
	#debug => 1,
);

$cl->reg_cb(
	connected => sub {
		my ($q,$c,$host,$port) = @_;
		warn "source $host:$port connected";
		my $count = 0;
#=for rem
		for (1..10) {
			$cl->put(
				dst => 'test',
				data => { z => '1'x100 },
				cb => sub {
					$count++;
					measure('put '.$count);
					if ( my $job = shift ) {
						#warn "stored: ".$job->id;
					} else {
						warn "@_";
					}
				}
			)
		}
#		return;
#=cut
		warn "Adds queued";
		my $w;$w = $cl->watcher(
			src => 'test',
			prefetch => 10,
			job => sub {
				shift;
				if ( my $job = shift ) {
					$count++;
					measure('job '.$count);
					warn $count if !( $count % 100 );
					
					#$w->release(job => $job, cb => sub {});
					#undef $job;
					#return;
					#my $t; $t = AnyEvent->timer(after => 0, interval => 0.0001, cb => $do);
					

					$cl->_add( 'put',
						dst  => 'test',
						data => 'y'x1000,#$job->data,
						cb   => sub {
							measure('put '.$count);
							if (shift) {
								$w->ack(job => $job);
							} else {
								$w->release(job => $job);
							}
							undef $job;
						},
					);
					return;
				}
			},
			nomore => sub {
				warn "No more";
				$cv->send;
			},
		);
		$SIG{TERM} = $SIG{INT} = sub {
			$cv->send;
			#$w->stop(cb => sub{ $cv->send });
		};
	},
);
measure('client');
$cl->connect;
$cv->recv;
warn "Finishing";

__END__
my $cl = AnyEvent::AtomStream::Client->new(
    GET => 'http://atom.services.livejournal.com/atom-stream.xml',
    since => time,
    reconnect => 1,
);
my $maxsize = 0;
my $do_sleep = 0;
my $count = 0;
my $cyr = 0;
my $start = time;
$cl->reg_cb(
	connected => sub {
		my $t;$t = AnyEvent->timer(after=>10, cb => sub {
			undef $t;
			#$do_sleep = 1;
			#warn "reconnect after "
			#$cl->reconnect;
		});
	},
	entry => sub {
		shift;
		my $h = shift;
		measure('entry');
		$count++;
		my $size = total_size $h;
		my $delta = $size - $maxsize;
		if ($delta > 0) {
			$maxsize = $size;
			warn sprintf "%s maxsize grow by %+d (size=%d)\n",~~localtime, $delta,$size;
		}
		#warn Dump + $h;#$cv->send;
		m{()};
		my $is_cyr = 1,$cyr++ if ($h->{entry}{title}.$h->{entry}{content}) =~ /(\p{IsCyrillic})/;
		warn sprintf "[%s] [%d/%d] [%0.1f/s:%0.1f/s] [%s] %s: %s\n",
			~~localtime, $count, $cyr, $count/((time-$start)||1), $cyr/((time-$start)||1), $is_cyr ? 'Y' : 'N',
			$h->{entry}{poster}{name},$h->{entry}{title};
	},
	time  => sub {
		shift;
		my $time = shift;
		warn "time: $time, delta=".(time-$time)."\n";
		measure('time');
	},
	slow  => sub { shift;warn "slow:". R::Dump (@_); },
	error => sub { shift;warn "error:". R::Dump (@_); },
	parser_error => sub {
		shift;
		my ($data,$err) = @_;
		warn "Parsing failed: $err\n$data";
	}
);
$cl->connect;

$cv->recv;
warn "Finishing";

__END__
AnyEvent::AtomStream::Client->request(sub {
	print Dump \@_;
});
$cv->recv;
warn "Finishing";
